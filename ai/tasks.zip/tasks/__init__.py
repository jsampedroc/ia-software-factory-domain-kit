# ai/tasks/__init__.py
from .domain_model_task import build_domain_model_task
from .architecture_task import build_architecture_task
from .code_generation_task import build_code_generation_task
from .write_tests_task import build_write_tests_task
from .audit_code_task import build_audit_code_task
from .heal_code_task import build_heal_code_task
from .project_debug_task import build_project_debug_task

__all__ = [
    "build_domain_model_task",
    "build_architecture_task",
    "build_code_generation_task",
    "build_write_tests_task",
    "build_audit_code_task",
    "build_heal_code_task",
    "build_project_debug_task"
]