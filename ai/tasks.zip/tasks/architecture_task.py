# ai/tasks/architecture_task.py

def build_architecture_task(domain_kit="", **kwargs):
    # Si domain_kit viene vacío pero context_data no, lo recuperamos
    dk = domain_kit if domain_kit else kwargs.get('context_data', '')
    base_package = kwargs.get('base_package', 'com.application')
    base_package_path = kwargs.get('base_package_path', 'com/application')

    return {
        "agent": "architect",
        "description": f"""
        Basado en este Domain Kit: {dk}
        Tarea: Diseña el inventario de archivos para una Arquitectura Hexagonal.
        
        REGLAS DE RUTA INNEGOCIABLES:
        1. PAQUETES: Usa únicamente '{base_package}.domain.model', '.domain.valueobject', '.domain.repository' y '.application.service'.
        2. RUTA MAVEN: Todo archivo debe empezar por 'backend/src/main/java/{base_package_path}/'.
        3. ESTRUCTURA PLANA: No crees subcarpetas adicionales dentro de las capas.
        
        Debes devolver UNICAMENTE un JSON con este formato:
        [
          {{"path": "backend/src/main/java/{base_package_path}/domain/model/Entidad.java", "description": "crea la entidad"}}
        ]
        """,
        "expected_output": "JSON de inventario."
    }