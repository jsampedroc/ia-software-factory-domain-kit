def build_audit_code_task(path, base_package, context_data=""):
    return {
        "agent": "qa_agent",
        "description": f"""
        Audita la calidad y arquitectura del archivo '{path}'.
        REGLAS CRÍTICAS:
        1. SINTAXIS: Verifica 'implements ValueObject' y 'extends Entity'.
        2. PAQUETES: Asegura que el package empiece por '{base_package}'.
        3. ENUMS: Revisa que no se usen enums inexistentes.
        """,
        "expected_output": "Responde 'APROBADO' o una lista de errores técnicos."
    }