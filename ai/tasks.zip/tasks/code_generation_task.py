def build_code_generation_task(path, description, context_data):
    return {
        "description": f"""
        Implementa el archivo '{path}' ({description}).
        
        CONTEXTO TÉCNICO:
        {context_data}
        
        REGLAS DE ORO:
        - Usa Java 17 Records para todos los Value Objects.
        - Asegura que los paquetes coincidan con el mapa del proyecto.
        - No dejes métodos sin implementar.
        """,
        "expected_output": "Código fuente puro Java 17."
    }