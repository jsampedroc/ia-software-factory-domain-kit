# ai/tasks/domain_model_task.py

def build_domain_model_task(idea, base_package, **kwargs):
    return {
        "agent": "domain_reasoner",
        "description": f"""
        Analiza la siguiente idea de negocio: '{idea}'
        REGLA DE CONTEXTO: El paquete raíz del sistema es '{base_package}'.
        
        Tarea: Crea un Domain Kit profesional en Markdown que incluya:
        1. Lenguaje Ubicuo (Glosario).
        2. Entidades y Atributos (con tipos de datos Java 17).
        3. Relaciones (1:N, N:N).
        4. Reglas de Negocio críticas.
        """,
        "expected_output": "Un documento Markdown con el ADN del negocio."
    }