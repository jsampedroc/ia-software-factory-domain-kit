def build_heal_code_task(path, error_log, base_package, context_data=""):
    return {
        "agent": "backend_builder",
        "description": f"""
        REPARACIÓN: El archivo '{path}' falló. 
        ERROR MAVEN: '{error_log}'.
        TAREA: Corrige el código para solucionar el error respetando el paquete '{base_package}'.
        """,
        "expected_output": "Código fuente corregido."
    }