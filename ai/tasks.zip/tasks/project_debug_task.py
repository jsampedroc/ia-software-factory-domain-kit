def build_project_debug_task(error_log, base_package, **kwargs):
    return {
        "agent": "qa_agent",
        "description": f"""
        Analiza este fallo masivo de Maven: '{error_log}'.
        Identifica inconsistencias de contratos o paquetes en '{base_package}'.
        """,
        "expected_output": "Guía de reparación estructural."
    }