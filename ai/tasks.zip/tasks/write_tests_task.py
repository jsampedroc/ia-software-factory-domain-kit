def build_write_tests_task(path, base_package, context_data=""):
    return {
        "agent": "backend_builder",
        "description": f"""
        Genera la batería de tests unitarios (JUnit 5 + Mockito + AssertJ) para el archivo '{path}'.
        REGLAS DE ORO:
        1. INSTANCIACIÓN: Las entidades tienen constructores PROTECTED. Usa ÚNICAMENTE '[Clase].create(...)' para instanciarlas.
        2. IDENTIDADES: No mockees los IDs. Instáncialos: 'new NombreId(UUID.randomUUID())'.
        3. MOCKS: Usa @ExtendWith(MockitoExtension.class) y @Mock para las dependencias.
        4. PAQUETE: El paquete raíz es '{base_package}'. El archivo debe ir en 'src/test/java/...'.
        """,
        "expected_output": "Código JUnit 5 profesional."
    }